import { Component } from '@angular/core';
import { NgIf } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { LoggerService } from '../../services/logger.service';

@Component({
  selector: 'app-number-validation',
  standalone: true,
  imports: [NgIf, FormsModule],
  templateUrl: './number-validation.component.html',
  styleUrls: ['./number-validation.component.scss'],
})
export class NumberValidationComponent {
  numberInput: string = '';
  result: string | null = null;
  isMultipleOfFive: boolean | null = null;
  errorMessage: string | null = null;
  isLoading = false;
  retryTimeLeft: number | null = null;
  intervalId: any;

  constructor(
    private apiService: ApiService,
    private loggerService: LoggerService
  ) {}

  checkNumber() {
    if (!this.numberInput) {
      this.errorMessage = 'Please enter a valid number between 0 and 10000!';
      return;
    }

    this.isLoading = true;
    this.errorMessage = null;
    this.result = null;
    this.isMultipleOfFive = null;

    this.apiService.checkNumber(this.numberInput).subscribe(
      (response: any) => {
        this.isLoading = false;
        this.isMultipleOfFive = response?.isMultipleOfFive;
        this.result = response?.isMultipleOfFive
          ? ` ${response?.number} is a multiple of 5`
          : ` ${response?.number} is NOT a multiple of 5`;

        this.loggerService.logRequestTime(
          'NumberValidationAPI',
          response.duration
        );
      },
      (error: any) => {
        this.isLoading = false;

        if (error instanceof Error) {
          try {
            const parsedError = JSON.parse(error.message);
            if (parsedError.retryAfter) {
              this.startCountdown(parsedError.retryAfter);
            } else {
              this.errorMessage =
                parsedError.message ||
                'Something went wrong. Please try again later.';
            }
          } catch {
            this.errorMessage = ' An unexpected error occurred.';
          }
        } else {
          this.errorMessage = ' Unable to process request.';
        }
      }
    );
  }

  startCountdown(seconds: number) {
    this.retryTimeLeft = seconds;
    this.intervalId = setInterval(() => {
      if (this.retryTimeLeft !== null) {
        this.retryTimeLeft--;
        if (this.retryTimeLeft <= 0) {
          clearInterval(this.intervalId);
          this.retryTimeLeft = null;
        }
      }
    }, 1000);
  }
}
