import { Component } from '@angular/core';
import { NumberValidationComponent } from './components/number-validation/number-validation.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [NumberValidationComponent],
  template: `<app-number-validation></app-number-validation>`,
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {}
