import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class LoggerService {
  logRequestTime(apiName: string, duration: number) {
    console.log(`API: ${apiName} took ${duration.toFixed(2)}ms`);
  }
}
