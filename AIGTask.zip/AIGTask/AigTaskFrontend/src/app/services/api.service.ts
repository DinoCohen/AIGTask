import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  private readonly API_URL = environment.apiUrl;

  constructor(private http: HttpClient) {}

  checkNumber(
    number: string
  ): Observable<
    | { number: string; isMultipleOfFive: boolean; duration: number }
    | { message: string; retryAfter?: number }
  > {
    const startTime = performance.now();

    return this.http
      .post<{ number: string; isMultipleOfFive: boolean }>(this.API_URL, {
        number,
      })
      .pipe(
        map((response) => {
          const duration = performance.now() - startTime;
          return { ...response, duration };
        }),
        catchError((error: HttpErrorResponse) => {
          if (error.status === 429) {
            const retryAfter = parseInt(
              error.headers.get('Retry-After') || '60',
              10
            );
            return throwError(
              () =>
                new Error(
                  JSON.stringify({ message: 'Rate limit exceeded', retryAfter })
                )
            );
          }
          return throwError(
            () => new Error(JSON.stringify({ message: 'Something went wrong' }))
          );
        })
      );
  }
}
