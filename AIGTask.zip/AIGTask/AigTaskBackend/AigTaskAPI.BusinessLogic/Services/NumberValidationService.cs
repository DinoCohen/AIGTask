﻿using Microsoft.Extensions.Logging;

namespace AigTask.BusinessLogic.Services
{
    public class NumberValidationService : INumberValidationService
    {
        private readonly ILogger<NumberValidationService> _logger;

        public NumberValidationService(ILogger<NumberValidationService> logger)
        {
            _logger = logger;
        }

        public bool IsMultipleOfFive(int number)
        {
            bool result = number % 5 == 0;
            _logger.LogInformation($"Checked number {number}: IsMultipleOfFive = {result}");
            return result;
        }
    }
}

