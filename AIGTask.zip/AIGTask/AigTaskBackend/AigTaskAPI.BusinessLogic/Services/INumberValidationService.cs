﻿namespace AigTask.BusinessLogic.Services
{
    public interface INumberValidationService
    {
        bool IsMultipleOfFive(int number);
    }
}