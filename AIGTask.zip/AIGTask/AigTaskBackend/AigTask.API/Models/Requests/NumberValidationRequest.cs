﻿using System.ComponentModel.DataAnnotations;

namespace AigTask.API.Models.Requests
{
    public class NumberValidationRequest
    {
        [Required]
        public string Number { get; set; }
    }
}