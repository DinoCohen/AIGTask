﻿using AigTask.API.Models.Requests;
using AigTask.BusinessLogic.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace AigTask.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class NumberValidationController : ControllerBase
    {
        private readonly INumberValidationService _numberValidationService;
        private readonly ILogger<NumberValidationController> _logger;

        public NumberValidationController(INumberValidationService numberValidationService, ILogger<NumberValidationController> logger)
        {
            _numberValidationService = numberValidationService;
            _logger = logger;
        }

        [HttpPost("ValidateNumber")]
        public IActionResult ValidateNumber([FromBody] NumberValidationRequest request)
        {
            _logger.LogInformation($"Received request with number: {request.Number}");

            if (!int.TryParse(request.Number, out int parsedNumber) || parsedNumber < 0 || parsedNumber > 10000)
            {
                _logger.LogWarning($"Invalid input received: {request.Number}");
                return BadRequest(new { message = "Invalid input. Must be an integer string between 0 and 10000." });
            }

            bool isMultipleOfFive = _numberValidationService.IsMultipleOfFive(parsedNumber);
            return Ok(new { number = request.Number, isMultipleOfFive });
        }
    }
}